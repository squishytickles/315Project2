import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JComponent;


public class CircleComponent extends JComponent {
	
    @Override
    public void paint(Graphics g)
    {
        int height = 20;
        int width = 20;
        g.setColor(Color.red);
        g.drawOval(20, 20, height, width);
        g.fillOval(20, 20, height, width);
    }
}