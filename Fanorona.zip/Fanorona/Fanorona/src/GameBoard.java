import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GameBoard extends JFrame implements ActionListener  {

	@Override
	public void actionPerformed(ActionEvent arg0)  {
		
		GameBoard frame = null;
		frame = new GameBoard();
		frame.setSize(620, 450);
		
		JPanel contentPane = new JPanel(new BorderLayout());
				
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		String image = "GameBoard.jpg";
		JLabel boardBackground = new JLabel(new ImageIcon(image));
		boardBackground.setHorizontalAlignment(JLabel.CENTER);
		contentPane.add(boardBackground);
		
		frame.add(contentPane);
		frame.setVisible(true);
	}
}