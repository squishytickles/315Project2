import javax.swing.JPanel;

public class GamePiece {
	
	private int xCoord, yCoord;
	
	public GamePiece(JPanel contentPane, int x, int y) {
		
		//set Piece to point (xCoord, yCoord) in window
		contentPane.add(new CircleComponent());	
	}
	
	public void deleteGamePiece(){
		
		
		return;
	}
	
	public void updateCoordinates(int newX, int newY){
		
		
		return;
	}
}